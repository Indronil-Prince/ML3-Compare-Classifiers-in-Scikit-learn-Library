Instructions to run the program:
1. Ensure you have Python installed on your machine.
2. Install required libraries by running 'pip install pandas matplotlib'.
3. Keep the data files in the same directory of the script.
4. Run the Python script to execute the program.